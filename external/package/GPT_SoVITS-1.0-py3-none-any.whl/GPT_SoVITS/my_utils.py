import ffmpeg
import numpy as np


def load_audio(file, sr):
    try:
        # https://github.com/openai/whisper/blob/main/whisper/audio.py#L26
        # This launches a subprocess to decode audio while down-mixing and resampling as necessary.
        # Requires the ffmpeg CLI and `ffmpeg-python` package to be installed.
        file = (
            file.strip(" ").strip('"').strip("\n").strip('"').strip(" ")
        )  # 防止小白拷路径头尾带了空格和"和回车
        out, _ = (
            ffmpeg.input(file, threads=0)
            .output("-", format="f32le", acodec="pcm_f32le", ac=1, ar=sr)
            .run(cmd=["ffmpeg", "-nostdin"], capture_stdout=True, capture_stderr=True)
        )
    except Exception as e:
        raise RuntimeError(f"Failed to load audio: {e}")

    return np.frombuffer(out, np.float32).flatten()


if __name__ == '__main__':
    import torch

    dict_s = torch.load("/Users/viking/ai/github/GPT-SoVITS/SoVITS_weights/ningning_e8_s80.pth", map_location="cpu")
    print(dict_s)
    # import logging
    # from inference_webui import InferenceWebUI
    # import os
    #
    # external = InferenceWebUI(
    #     "/Users/viking/ai/github/GPT-SoVITS/GPT_SoVITS/pretrained_models/chinese-roberta-wwm-ext-large",
    #     "/Users/viking/ai/github/GPT-SoVITS/GPT_SoVITS/pretrained_models/chinese-hubert-base",
    #     "/Users/viking/ai/github/GPT-SoVITS/GPT_weights/ningning-e15.ckpt",
    #     "/Users/viking/ai/github/GPT-SoVITS/SoVITS_weights/ningning_e8_s80.pth")
    #
    # # gpt微调权重
    # external.change_gpt_weights(gpt_path=external.gpt_path)
    # # sovits微调权重
    # external.change_sovits_weights(sovits_path=external.sovits_path)
    # # 生成wav
    # synthesis_result = external.get_tts_wav(
    #     ref_wav_path="/Users/viking/ai/study/GPT-SoVITS/GPT_SoVITS/prepare_datasets/stage.wav_1266880_1398080.wav",
    #     prompt_text="发了一张刚才的自拍，然后我爸我妈说美",
    #     # prompt_language=EXAMPLE_TEXT_LANG,
    #     text="我是宁艺卓，我爱你，我是真的爱你"
    #     # text_language=lang
    # )
    #
    # result_list = list(synthesis_result)
    #
    # import soundfile as sf
    #
    # OUTPUT_WAV_PATH = "/Users/viking/ai/github/GPT-SoVITS/GPT_SoVITS"
    # if result_list:
    #     last_sampling_rate, last_audio_data = result_list[-1]
    #     output_wav_path = os.path.join(OUTPUT_WAV_PATH, "output.wav")
    #     sf.write(output_wav_path, last_audio_data, last_sampling_rate)
    #
    #     result = "Audio saved to " + output_wav_path
    #
    # logging.info(f"合成完成！输出路径：{OUTPUT_WAV_PATH}")
    # logging.info("处理结果：\n" + result)
