if __name__ == '__main__':
    import torch

    dict_s = torch.load("/Users/viking/ai/github/GPT-SoVITS/SoVITS_weights/ningning_e8_s80.pth", map_location="cpu")
    print(dict_s)