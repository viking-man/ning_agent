import json
import locale
import os
import json
from importlib.resources import open_text, path
from importlib import resources


def load_language_list(language):
    resource_path = f"{language}.json"
    with open_text("GPT_SoVITS.i18n.locale", resource_path) as f:
        language_list = json.load(f)
    return language_list

    # # 假设 'some_package' 是外部包名，'data' 是包内的目录，'example.json' 是目标文件
    # with path("GPT_SoVITS.i18n.locale", f"locale/{language}.json") as f:
    #     language_list = json.load(f)
    # return language_list
    #
    # absolute_path = os.path.abspath(f"locale/{language}.json")
    # with open(absolute_path, "r", encoding="utf-8") as f:
    #     language_list = json.load(f)
    # return language_list


class I18nAuto:
    def __init__(self, language=None):
        if language in ["Auto", None]:
            language = locale.getdefaultlocale()[
                0
            ]  # getlocale can't identify the system's language ((None, None))
        resource_path = f"{language}.json"
        if not resources.is_resource("GPT_SoVITS.i18n.locale", resource_path):
            language = "en_US"
        self.language = language
        self.language_map = load_language_list(language)

    def __call__(self, key):
        return self.language_map.get(key, key)

    def __repr__(self):
        return "Use Language: " + self.language
