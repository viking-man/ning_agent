from setuptools import setup, find_packages

setup(
    name="GPT_SoVITS",
    version="1.0",
    packages=find_packages(),
    description="GPT TTS package",
    author="Noone",
    license="MIT",
    package_data={
        # 如果你的包名称是 "your_package"，并且你想包含所有 txt 文件
        "GPT_SoVITS": ["*.txt"],
        # 如果你有深层次的文件夹结构并且想要包含所有 txt 文件
        "GPT_SoVITS.text": ["*.txt", "*.rep", "*.pickle", "GPT_SoVITS/text/*.txt"],
        "GPT_SoVITS.i18n.locale": ["*.json"],
    },
    install_requires=[
        "numpy",
        "scipy",
        "tensorboard",
        "librosa",
        "numba",
        "pytorch-lightning",
        "gradio",
        "ffmpeg-python",
        "onnxruntime",
        "tqdm",
        "funasr",
        "cn2an",
        "pypinyin",
        "pyopenjtalk",
        "g2p_en",
        "torchaudio",
        "modelscope",
        "sentencepiece",
        "transformers",
        "chardet",
        "PyYAML",
        "psutil",
        "jieba_fast",
        "jieba",
        "LangSegment"
    ]
)
